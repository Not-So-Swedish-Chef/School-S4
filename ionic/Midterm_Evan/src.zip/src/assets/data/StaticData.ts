import { DataFormat } from "../../app/DataFormat";

export const StaticData : DataFormat = {
    title : "Static Data",
    desc  : "Sample static data here (data found in Static Data in assets and assigned in app-routing)." 
};